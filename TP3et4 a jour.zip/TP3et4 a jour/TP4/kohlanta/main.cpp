#include <iostream>
#include <cstdlib>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string>
#include <unistd.h>
#include <sys/sem.h>

using namespace std;


int main(){

	int nbzone;
	int nbtraitement;

union semun{
	int val;
	struct semid_ds *buf;
	unsigned short *array;
	struct seminfo *__buf;
} arg_ctrl;

	cout << "NB ZONE ";
	cin >> nbzone;

	cout << "NB TRAITEMENT ";
	cin >> nbtraitement;

	key_t cle;
	int f_id;


	cle = ftok("docufile",8);
	f_id = semget(cle,nbzone+2,IPC_CREAT|IPC_EXCL|0666);
	if ( f_id == -1) {
		f_id = semget(cle,1,0666);
		semctl(f_id,0,IPC_RMID);
		perror("erreur creation");}

	cout << "f_id =" << f_id << endl;
	arg_ctrl.val= nbtraitement;

	for (int i=2;i<nbzone+2;i++){
	if (semctl(f_id,i,SETVAL,arg_ctrl) ==  -1) {cout << "erreur init " << endl;}}

	arg_ctrl.val= nbzone;
	if (semctl(f_id,0,SETVAL,arg_ctrl) ==  -1) {cout << "erreur init " << endl;}

	arg_ctrl.val= nbtraitement;
	if (semctl(f_id,1,SETVAL,arg_ctrl) ==  -1) {cout << "erreur init " << endl;}

	unsigned short array2[nbzone+1];
	
	semctl(f_id,0,GETALL,&array2);
	for (int i=0;i<nbzone+1;i++)cout << "Zone :" << i << " valeur : " << array2[i] << endl;



	return 0;
}