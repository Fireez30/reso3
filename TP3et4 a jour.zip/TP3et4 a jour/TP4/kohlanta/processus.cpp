#include <iostream>
#include <cstdlib>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string>
#include <ctime>
#include <unistd.h>
#include <sys/sem.h>
using namespace std;

int main(){


	int numtraitement=2;

	key_t cle;
	int f_id;
	int nbzone;

	struct sembuf opv;
	struct sembuf opp;

	srand(time(NULL));
	int temps = 0;


/*	union semun{
	int val;
	struct semid_ds *buf;
	unsigned short *array;
	struct seminfo *__buf;
} arg;
*/
	cle = ftok("docufile",8);
	f_id = semget(cle,1,0666); 
	if ( f_id == -1) {perror("erreur create");}

	cout << "id du tableau de semaphores : " << f_id << endl;
	
	opv.sem_op=-1;
	opv.sem_flg=0;

	/*while (true) {
		int temps = rand() %4;
		
		sleep(temps);
		
		if ( semop(f_id,&opv,1) == -1) {perror("erreur operation");}
	
		cout << "Entrée" << endl;
	semctl(f_id,0,GETALL,&array2);
	cout << "Nb places :" << array2[0] << endl;
	*/

	int max=semctl(f_id,0,GETVAL,NULL);
	cout << "Nb ZONE " << max << endl;

	int nbtraitement=semctl(f_id,1,GETVAL,NULL);
	cout << "Nb traitement " << nbtraitement << endl;

	for (int i=i; i< max+2;i++){

	if (semctl(f_id,i,GETVAL,NULL) != nbtraitement - numtraitement){
		cout << "en attente du traitement precedent " << endl;
		sleep(1);
		i--;
		continue;
	}
	
	sleep(3);
	opv.sem_num=i;
	semop(f_id,&opv,1);
	cout << "Travail " << i << " terminé ! " << endl;
}

unsigned short array2[max+2];
	semctl(f_id,0,GETALL,&array2);
	for (int i=1;i<max+2;i++)cout << "Zone :" << i << " valeur : " << array2[i] << endl;

	return 0;
}