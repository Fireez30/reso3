#include <iostream>
#include <cstdlib>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string>
#include <ctime>
#include <unistd.h>
#include <sys/sem.h>
using namespace std;

struct sembuf opv;
struct sembuf opa;
typedef struct s_parames{
	int p;
	unsigned short *tab;
} parames;

union semun{
	int val;
	struct semid_ds *buf;
	unsigned short *array;
	struct seminfo *__buf;
} arg;


void * rdv(void * ip){

	semctl(((parames*)ip)->p,0,GETALL,((parames*)ip)->tab);
	cout << "Nb encore en attente :" << ((parames*)ip)->tab[0] << endl;
semop(((parames*)ip)->p,&opv,1);
cout << "Attente" << endl;
semop(((parames*)ip)->p,&opa,1);
cout << "Rdv reussi " << endl;

pthread_exit(0);
}

int main(){

	int n;

	cout << "Nombre de processus au rdv (meme nombre qu'a linitialisation : "<< endl;
	cin >> n;
	parames e;
	srand(time(NULL));
	key_t cle;
	int f_id;
	pthread_t tasks [n];
	opv.sem_num=0;
	opv.sem_op=-1;
	opv.sem_flg=0;

	unsigned short array2[1];

	opv.sem_num=0;
	opv.sem_op=0;
	opv.sem_flg=0;

	cle = ftok("docufile",3);

	f_id = semget(cle,1,0666); 
	if ( f_id == -1) {perror("erreur create");}

	cout << "id du tableau de semaphores : " << f_id << endl;
	e.p=f_id;
	e.tab=array2;
	
	

	for (unsigned i (0); i < n; ++i) {
        if (pthread_create(&tasks[i], NULL, rdv,&e) != 0) cout << "creation error !" << endl;
    }

    for (unsigned i (0); i < n; ++i) {
        pthread_join(tasks[i], NULL);
    }

	return 0;
}